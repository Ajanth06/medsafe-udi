import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import AuthBar from "./components/AuthBar";
import Sidebar from "./components/Sidebar";

export const metadata: Metadata = {
  title: "MedSafe-UDI",
  description: "Dezentrale UDI- & Dokumentenverwaltung für Medizinprodukte",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="de" className="bg-slate-950">
      <body className="min-h-screen w-full bg-slate-950 text-slate-50 antialiased">
        <div className="relative min-h-screen w-full min-w-full overflow-visible bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
          {/* weiche Farb-Blobs */}
          <div className="pointer-events-none absolute -left-24 top-10 h-72 w-72 rounded-full bg-sky-500/20 blur-3xl" />
          <div className="pointer-events-none absolute -right-10 bottom-10 h-80 w-80 rounded-full bg-emerald-500/15 blur-3xl" />

          <div className="relative mx-auto flex min-h-screen w-full min-w-0 max-w-[1800px] flex-col gap-5 px-6 py-6 sm:px-8 lg:px-10 2xl:px-10">
            {/* HEADER */}
           <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between rounded-3xl border border-white/10 bg-white/5 px-4 py-3 shadow-lg shadow-slate-950/60 backdrop-blur-2xl gap-3">

  {/* Links: MEDSAFE-Card + Vogel */}
  <div className="flex items-center gap-4">
    {/* Glow-Card MEDSAFE-UDI */}
    <div className="rounded-2xl border border-sky-500/30 bg-sky-500/10 px-4 py-3 shadow-[0_0_20px_rgba(0,150,255,0.3)] backdrop-blur-xl">
      <div className="text-lg font-bold tracking-wide text-sky-100">
        MEDSAFE-UDI
      </div>
      <div className="text-[11px] text-slate-300/80 mt-0.5">
        UDI · MDR · DOCUMENT CLOUD
      </div>
    </div>

    {/* Vogel mit Glow + Bounce */}
   <div className="relative w-20 h-20 flex items-center justify-center">
  {/* Glow-Kreis */}
  <div className="absolute inset-0 rounded-full bg-sky-500/30 animate-ping" />

  {/* Innerer Kreis + Vogel */}
  <div className="relative w-10 h-10 rounded-full bg-slate-900 border border-sky-400 flex items-center justify-center float-soft">
    <img
      src="/icons/red-bird.svg"
      alt="MedSafe Bird"
      className="h-70 w-70"
    />
  </div>
</div>


  </div>

  {/* Rechts: Online-Status + AuthBar */}
  <div className="ml-auto flex flex-col items-end gap-2">
    <div className="hidden items-center gap-2 rounded-full border border-white/15 bg-black/30 px-3 py-1 text-[11px] text-slate-100/80 sm:flex">
      <span className="h-2 w-2 rounded-full bg-emerald-400 shadow shadow-emerald-500/80 animate-pulse" />
      <span>Online</span>
    </div>

    <AuthBar />
  </div>
</header>


            {/* Layout mit Sidebar + Inhalt */}
            <div className="flex flex-1 flex-col gap-4 md:flex-row">
              {/* Sidebar */}
              <aside className="md:w-64">
                <Sidebar />
              </aside>

              {/* Inhalt */}
              <section className="flex-1">
                <div className="flex h-full flex-col gap-4">
                  {/* Top-Karten */}
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="rounded-3xl border border-white/10 bg-white/5 p-4 text-sm shadow-lg shadow-slate-950/60 backdrop-blur-2xl">
                      <div className="text-[11px] uppercase tracking-[0.22em] text-slate-300/80">
                        Überblick
                      </div>
                      <div className="mt-1 text-sm font-semibold text-slate-50">
                        Geräte &amp; UDI-Verwaltung
                      </div>
                    </div>

                    <div className="rounded-3xl border border-emerald-500/20 bg-emerald-500/10 p-4 text-sm shadow-lg shadow-emerald-900/50 backdrop-blur-2xl">
                      <div className="text-[11px] uppercase tracking-[0.22em] text-emerald-200/90">
                        Integrität
                      </div>
                      <div className="mt-1 text-sm font-semibold text-emerald-50">
                        UDI-Hash aktiv
                      </div>
                    </div>

                    <div className="rounded-3xl border border-sky-500/25 bg-sky-500/10 p-4 text-sm shadow-lg shadow-sky-900/50 backdrop-blur-2xl">
                      <div className="text-[11px] uppercase tracking-[0.22em] text-sky-100/90">
                        Status
                      </div>
                      <div className="mt-1 text-sm font-semibold text-sky-50">
                        Cloud-Register
                      </div>
                    </div>
                  </div>

                  {/* Seiteninhalt */}
                  <main className="flex-1 overflow-visible rounded-3xl border border-white/10 bg-black/40 p-4 shadow-inner shadow-slate-950/70 backdrop-blur-2xl sm:p-6">
                    {children}
                  </main>
                </div>
              </section>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}
